CREATE TABLE LOCATION (
  Location_ID INT PRIMARY KEY,
  City VARCHAR(50)
);

INSERT INTO LOCATION (Location_ID, City)
VALUES (122, 'New York'),
       (123, 'Dallas'),
       (124, 'Chicago'),
       (167, 'Boston');


  CREATE TABLE DEPARTMENT (
  Department_Id INT PRIMARY KEY,
  Name VARCHAR(50),
  Location_Id INT,
  FOREIGN KEY (Location_Id) REFERENCES LOCATION(Location_ID)
);


INSERT INTO DEPARTMENT (Department_Id, Name, Location_Id)
VALUES (10, 'Accounting', 122),
       (20, 'Sales', 124),
       (30, 'Research', 123),
       (40, 'Operations', 167);

	   CREATE TABLE JOB (
  Job_ID INT PRIMARY KEY,
  Designation VARCHAR(50)
);

CREATE TABLE JOB
(JOB_ID INT PRIMARY KEY,
DESIGNATION VARCHAR(20))

INSERT  INTO JOB VALUES
(667, 'CLERK'),
(668,'STAFF'),
(669,'ANALYST'),
(670,'SALES_PERSON'),
(671,'MANAGER'),
(672, 'PRESIDENT')


CREATE TABLE EMPLOYEE
(EMPLOYEE_ID INT,
LAST_NAME VARCHAR(20),
FIRST_NAME VARCHAR(20),
MIDDLE_NAME CHAR(1),
JOB_ID INT FOREIGN KEY
REFERENCES JOB(JOB_ID),
MANAGER_ID INT,
HIRE_DATE DATE,
SALARY INT,
COMM INT,
DEPARTMENT_ID  INT FOREIGN KEY
REFERENCES DEPARTMENT(DEPARTMENT_ID))

INSERT INTO EMPLOYEE VALUES
(7369,'SMITH','JOHN','Q',667,7902,'17-DEC-84',800,NULL,20),
(7499,'ALLEN','KEVIN','J',670,7698,'20-FEB-84',1600,300,30),
(7505,'DOYLE','JEAN','K',671,7839,'04-APR-85',2850,NULl,30),
(7506,'DENNIS','LYNN','S',671,7839,'15-MAY-85',2750,NULL,30),
(7507,'BAKER','LESLIE','D',671,7839,'10-JUN-85',2200,NULL,40),
(7521,'WARK','CYNTHIA','D',670,7698,'22-FEB-85',1250,500,30)

1)----List all the employee details
select*from employees;

2)----List all the department details.
select*from department;

3)----List all job details.
select*from job;

4)----List all the locations.
select*from location;

5)----List out the First Name, Last Name, Salary, Commission for allEmployees
select first_name, last_name, salary, commission from employee;

6)----List out the Employee ID, Last Name, Department ID for all employeesandalias.
select employee_id, last_name, department_id, from employee;

7)----List out the annual salary of the employees with their names only.
select concat(first_name, last_name) as employee_name, salary*12 as annual_salary from employee;

-------------------WHERE CONDITION--------------------------------------------

1)----List the details about "Smith".
select*from employee where last_name = 'smith';

2)----List out the employees who are working in department 20.
select*from employee where department_id = 20;

3)----List out the employees who are earning salaries between 3000and4500.
select*from employee where salary between 3000 and 4500;

4)----List out the employees who are working in department 10 or 20.
select*from employee where DEPARTMENT_ID in (10, 20);

5)----Find out the employees who are not working in department 10 or 30.
select * from employee where department_id not in (10, 30);

6)----List out the employees whose name starts with 'S'.
select * from employee where first_name like 's';

7)----List out the employees whose name starts with 'S' and ends with'H'.
select first_name from employee
where first_name like 's%h';

8)----List out the employees whose name length is 4 and start with 'S'.
select * from first_name from employee
where first_name like 's_ _' and length (first_name) = 4;

9)----List out employees who are working in department 10 and drawsalariesmorethan 3500.
select first_name from EMPLOYEE
where department = 10 and salary > 3500;

10)----. List out the employees who are not receiving commission.
select first_name from employee
where commission is null;

----------------------------ORDER BY CLAUSE-------------------------------------------

1)----List out the Employee ID and Last Name in ascending order basedontheEmployee ID.

select employee_id, last_name from employee
order by employee_id asc;

2)----List out the Employee ID and Name in descending order based onsalary.

SELECT EmployeeID, Name
FROM employee
ORDER BY Salary DESC;

3)----List out the employee details according to their Last Name in ascending-order.

SELECT Employee_ID, First_Name, Last_Name FROM employees
ORDER BY Last_Name ASC;

4)----List out the employee details according to their Last Name in ascendingorder and then Department ID in descending order.

SELECT EmployeeID, First_Name, Last_Name, Department_ID
FROM employee
ORDER BY Last_Name ASC, Department_ID DESC;

--------------------------------GROUP BY and HAVING Clause-------------------------------------------------------------------------------------------

1)----How many employees are in different departments in the organization?

SELECT Department_ID, COUNT(*) as NumEmployees FROM employee
GROUP BY Department_ID;

2)----List out the department wise maximum salary, minimumsalary andaverage salary of the employees.

SELECT Department_ID,
       MAX(Salary) as MaxSalary,
       MIN(Salary) as MinSalary,
       AVG(Salary) as AvgSalary
FROM employee
GROUP BY Department_ID;

3)----List out the job wise maximum salary, minimum salary and averagesalary of the employees.

SELECT Job_Id
       MAX(Salary) as MaxSalary,
       MIN(Salary) as MinSalary,
       AVG(Salary) as AvgSalary
FROM employee
GROUP BY Job_Id;

4)----List out the number of employees who joined each month in ascendingorder.

SELECT EXTRACT(MONTH FROM HireDate ) as HireDate,
       EXTRACT(YEAR FROM HireDate) as HireYear,
       COUNT(*) as NumEmployeesJoined
FROM employee
GROUP BY HireMonth, HireYear
ORDER BY HireYear ASC, HireMonth ASC;

5)----List out the number of employees for each month and year in
ascending order based on the year and month.

SELECT EXTRACT(MONTH FROM HireDate ) as HireDate,
       EXTRACT(YEAR FROM HireDate) as HireYear,
       COUNT(*) as NumEmployeesJoined
FROM employee
GROUP BY HireMonth, HireYear
ORDER BY HireYear ASC, HireMonth ASC;

6)----List out the Department ID having at least four employees. 

SELECT Department_ID, COUNT(*) as NumEmployees
FROM employee
GROUP BY Department_ID
HAVING COUNT(*) >= 4;

7)----How many employees joined in the month of January?

SELECT COUNT(*) AS NumEmployeesJoined
FROM employees
WHERE EXTRACT(MONTH FROM JoinDate) = 1;

8)----How many employees joined in the month of January orSeptember?

SELECT COUNT(*) AS num_employees_jan_or_sep
FROM employee
WHERE MONTH(hire_date) = 1 OR MONTH(hire_date) = 9;

9)----How many employees joined in 1985?

SELECT COUNT(*) AS num_employees_1985
FROM employee
WHERE YEAR(hire_date) = 1985;

10)----How many employees joined each month in 1985?

SELECT 
    MONTH(hire_date) AS join_month,
    COUNT(*) AS num_employees_hired FROM employee
WHERE YEAR(hire_date) = 1985
GROUP BY MONTH(hire_date)
ORDER BY MONTH(hire_date);

11)----How many employees joined in March 1985?

SELECT 
    COUNT(*) AS num_employees_hired FROM employee
WHERE MONTH(hire_date) = 3
  AND YEAR(hire_date) = 1985;

12)----Which is the Department ID having greater than or equal to 3 employeesjoining in April 1985?

SELECT department_id,
  COUNT(*) AS num_employees_hired FROM employee
WHERE MONTH(hired_date) = 4
  AND YEAR(hired_date) = 1985
GROUP BY department_id
HAVING COUNT(*) >= 3;

-------------------------------JOINS---------------------------------------------

1)----List out employees with their department names.

SELECT emp.employee_id, emp.employee_name, dept.department_name
FROM employees emp
JOIN departments dept ON emp.department_id = dept.department_id;

2)----Display employees with their designations.

SELECT first_name,designation FROM employee;

3)----Display the employees with their department names and regional groups. 

SELECT emp.employee_id, emp.employee_name, dept.department_name, rg.regional_group_name
FROM employees emp
JOIN departments dept ON department_id = department_id
JOIN regional_groups rg ON regional_group_id = regional_group_id;

4)-----How many employees are working in different departments? Displaywithdepartment names.

SELECT department, COUNT(*) AS num_employee FROM employee
GROUP BY department;

5)----How many employees are working in the sales department?

SELECT COUNT(*) AS num_employees_in_sales FROM employee
WHERE department = 'Sales';

6)----Which is the department having greater than or equal to 5
employees? Display the department names in ascending
order.

SELECT department, COUNT(*) AS num_employees FROM employee
GROUP BY department
HAVING COUNT(*) >= 5
ORDER BY department ASC;

7)----How many jobs are there in the organization? Display with designations

SELECT COUNT(*) AS num_jobs, designation FROM jobs
GROUP BY designation;

8)----How many employees are working in "New York"?

SELECT COUNT(*) AS num_employees_in_new_york FROM employee
WHERE department = 'New York';

9)----Display the employee details with salary grades. Use conditional statementtocreate a grade column.

SELECT
  emp_id,
  emp_name,
  department,
  salary,
  CASE
    WHEN salary >= 80000 THEN 'A'
    WHEN salary >= 60000 THEN 'B'
    WHEN salary >= 40000 THEN 'C'
    ELSE 'D'
  END AS grade
FROM employee;

10)----List out the number of employees grade wise. Use conditional statementtocreate a grade column.

SELECT CASE
    WHEN salary >= 80000 THEN 'A'
    WHEN salary >= 60000 THEN 'B'
    WHEN salary >= 40000 THEN 'C'
    ELSE 'D'
  END AS grade,
  COUNT(*) AS num_employees FROM employees
GROUP BY grade;

11)----.Display the employee salary grades and the number of employees
between 2000 to 5000 range of salary.

SELECT CASE
    WHEN salary >= 80000 THEN 'A'
    WHEN salary >= 60000 THEN 'B'
    WHEN salary >= 40000 THEN 'C'
    ELSE 'D'
  END AS grade,
  COUNT(*) AS num_employees_in_range FROM employee
WHERE salary >= 2000 AND salary <= 5000 GROUP BY grade;

12)----Display all employees in sales or operation departments.

SELECT *FROM employees WHERE department IN ('Sales', 'Operation');

------------------------------------SET OPERATORS---------------------------------------------

1)----List out the distinct jobs in sales and accounting departments.

SELECT DISTINCT job FROM employees
WHERE department IN ('Sales', 'Accounting');

2)----List out all the jobs in sales and accounting departments.

SELECT job FROM employee
WHERE department = 'Sales'UNION SELECT job FROM employee
WHERE department = 'Accounting';

3)----List out the common jobs in research and accounting
departments in ascending order.

SELECT job FROM employees
WHERE department = 'Research'INTERSECT SELECT job
FROM employees WHERE department = 'Accounting'
ORDER BY job ASC;

----------------------------SUBQUERIES-----------------------------------

1)----Display the employees list who got the maximum salary.

SELECT emp_id, emp_name, department, salary FROM employees
WHERE salary = (
  SELECT MAX(salary) AS max_salary FROM employees
  );

2)----Display the employees who are working in the sales department.

SELECT emp_id, emp_name, department, salary FROM employee
WHERE department = 'Sales';

3)----Display the employees who are working as 'Clerk'.

SELECT emp_id, emp_name, department, salary FROM employee
WHERE job = 'Clerk';

4)----Display the list of employees who are living in "New York.

SELECT e.emp_id, emp_name, department, salary FROM employee
JOIN employee_residence r ON emp_id = emp_id
WHERE city = 'New York';

5)----Find out the number of employees working in the sales department.

SELECT COUNT(*) AS num_employees_in_sales FROM employee
WHERE department = 'Sales';

6)----Update the salaries of employees who are working as clerks on thebasisof
10%.

UPDATE employees
SET salary = salary * 1.1 -- 10% increase in salary
WHERE department = 'Clerk';

7)----Delete the employees who are working in the accounting department.

DELETE FROM employees
WHERE department = 'Accounting';

8)----Display the second highest salary drawing employee details.

SELECT * FROM employees
WHERE salary = (SELECT MAX(salary)FROM employee
WHERE salary < (SELECT MAX(salary))FROM employees
);

9)----Display the nth highest salary drawing employee details.

SELECT * FROM employees
ORDER BY salary DESC
LIMIT 1 OFFSET n-1;

10)----List out the employees who earn more than every employee in department 30.

SELECT *
FROM employees
WHERE salary > (
    SELECT MAX(salary)
    FROM employees
    WHERE department = 30
);

11)----List out the employees who earn more than the lowest salary in
department.Find out whose department has no employees.

SELECT * FROM employees e1
LEFT JOIN (
    SELECT department, MIN(salary) AS min_salary FROM employees
    GROUP BY department
) ON department = e2.department
WHERE e1.salary > COALESCE(e2.min_salary, 0);

12)----. Find out which department has no employees.

SELECT department FROM departments
LEFT JOIN employees ON departments.department_id = employees.department_id
WHERE employees.department_id IS NULL;

13)----Find out the employees who earn greater than the average salary for
their department.

SELECT *FROM employees e
JOIN (
    SELECT department, AVG(salary) AS avg_salary
    FROM employees
    GROUP BY department
) avg_salaries ON department = avg_salaries.department
WHERE salary > avg_salaries.avg_salary;



















